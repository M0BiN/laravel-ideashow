@extends('homePage')

@section('body')
    @livewire('landing.login')
@endsection