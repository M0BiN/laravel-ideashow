<!-- START ./Footer - Simple -->
<footer class="site-footer section block bg-contrast">
    <div class="container py-4">
        <div class="row align-items-center">
            <div class="col-md-5 text-center text-md-left">
                <nav class="nav justify-content-center justify-content-md-start"><a class="nav-item nav-link" href="about.html">About</a> <a class="nav-item nav-link" href="#">Services</a> <a class="nav-item nav-link" href="blog/blog-grid.html">Blog</a></nav>
            </div>
            <div class="col-md-2 text-center"><img src="img/landing/logo.png" alt="" class="logo"></div>
            <div class="col-md-5 text-center text-md-right">
                <p class="mt-2 mb-0 text-secondary small">© 2021 5studios. All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer>
<!-- End ./Footer - Simple  -->