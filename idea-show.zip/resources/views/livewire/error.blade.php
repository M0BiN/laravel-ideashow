<div>
    @error({{$for}})
        <span class="error">{{ $message }}</span>
    @enderror
</div>
