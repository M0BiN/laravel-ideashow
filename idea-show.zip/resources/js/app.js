require('./bootstrap');
import Alpine from '../../node_modules/alpinejs';

window.Alpine = Alpine;
Alpine.start();


