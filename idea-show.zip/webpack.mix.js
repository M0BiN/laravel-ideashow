const mix = require("laravel-mix");

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel applications. By default, we are compiling the CSS
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.js("resources/js/app.js", "public/js").postCss(
    "resources/css/app.css",
    "public/css",
    [require("postcss-import"), require("tailwindcss")]
);
mix.copy("resources/js/dashboard/app.js", "public/js/dashboard").copy(
    "resources/css/dashboard/app.css",
    "public/css/dashboard",
    [require("postcss-import"), require("tailwindcss")]
);
mix.copy("resources/img/dashboard", "public/img/dashboard");
mix.copy("resources/js/landing/*.js", "public/js/landing").copy(
    "resources/css/landing/*.css",
    "public/css/landing"
);
mix.copy("resources/fonts/landing", "public/fonts/landing").copy(
    "resources/img/landing",
    "public/img/landing"
);
if (mix.inProduction()) {
    mix.version();
}
